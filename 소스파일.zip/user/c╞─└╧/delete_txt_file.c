
void delete_file()
{
	remove("c:\\capston_temp\\start_programming.txt");
	remove("c:\\capston_temp\\random_number.txt");
}