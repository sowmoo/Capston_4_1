#ifndef COMPARE_H
#define COMPARE_H

#endif 